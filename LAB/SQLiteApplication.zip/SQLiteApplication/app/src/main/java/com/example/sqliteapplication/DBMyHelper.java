package com.example.sqliteapplication;

public interface DBMyHelper {
    Boolean onUpgrade(String name, String contact, String dob);
}
